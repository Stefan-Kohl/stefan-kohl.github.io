
This directory contains a copy of the author's thesis
`Restklassenweise affine Gruppen'.

An english translation is available upon request.

